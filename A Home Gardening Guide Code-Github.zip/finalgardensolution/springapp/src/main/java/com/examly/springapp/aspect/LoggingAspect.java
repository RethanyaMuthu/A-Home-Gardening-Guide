package com.examly.springapp.aspect;

public class LoggingAspect {
    
}
