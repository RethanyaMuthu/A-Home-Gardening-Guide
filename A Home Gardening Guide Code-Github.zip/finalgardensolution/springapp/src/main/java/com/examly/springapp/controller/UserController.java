package com.examly.springapp.controller;

import com.examly.springapp.model.*;
import com.examly.springapp.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/users")
public class UserController {
  @Autowired
  private  UserService userService;

  @GetMapping
  public ResponseEntity<List<User>> getAllUsers() {
    List<User>users = userService.getAllUsers();
    return ResponseEntity.ok(users);
  }

  @GetMapping("/{id}")
  public ResponseEntity<User> getUserById(@PathVariable Long id) {
    User user = userService.getUserById(id);
    return(user!=null)? ResponseEntity.ok(user): ResponseEntity.notFound().build();
  }

  @PutMapping("/{id}")
  public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User user) {
    User updatedUser = userService.updateUser(id, user);
    return(updatedUser!=null)? ResponseEntity.ok(updatedUser): ResponseEntity.notFound().build();
  }

  @PostMapping
  public ResponseEntity<User> addUser(@RequestBody User user) {
    User createdUser = userService.addUser(user);
    return ResponseEntity.status(201).body(createdUser);
  }

  @DeleteMapping("/{id}")

  public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
    userService.deleteUser(id);
    return ResponseEntity.noContent().build();
  }
}
