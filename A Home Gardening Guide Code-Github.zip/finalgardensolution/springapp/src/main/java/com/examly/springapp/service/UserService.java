package com.examly.springapp.service;

import com.examly.springapp.model.*;
import com.examly.springapp.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
   @Autowired
   private UserRepository userRepository;


   public List<User> getAllUsers() {
      return userRepository.findAll();
   }

   public User getUserById(Long id) {
      return userRepository.findById(id).orElse(null);
   }

   public User addUser(User user) {
      return userRepository.save(user);
   }

   public void deleteUser(Long id) {
      userRepository.deleteById(id);
   }

   public User updateUser(Long id, User updatedUser) {
      Optional<User> existingUserOptional = userRepository.findById(id);
      if (existingUserOptional.isPresent()) {
         User existingUser = existingUserOptional.get();
         existingUser.setName(updatedUser.getName());
         existingUser.setEmail(updatedUser.getEmail());
         existingUser.setPassword(updatedUser.getPassword());
         existingUser.setRole(updatedUser.getRole());
         return userRepository.save(existingUser);
      }
      return null;
   }

}
