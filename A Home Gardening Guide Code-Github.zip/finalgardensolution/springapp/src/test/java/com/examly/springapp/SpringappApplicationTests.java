package com.examly.springapp;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;


 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;


import com.fasterxml.jackson.databind.ObjectMapper;



import com.examly.springapp.model.Product;
import com.examly.springapp.service.ProductService;

import java.util.List;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.examly.springapp.controller.ProductController;
import com.examly.springapp.controller.TaskController;
import com.examly.springapp.controller.UserController;
import com.examly.springapp.model.Task;
import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepository;
import com.examly.springapp.service.TaskService;
import com.examly.springapp.service.UserService;

@SpringBootTest (classes = SpringappApplication.class)
@AutoConfigureMockMvc
public class SpringappApplicationTests {


	@InjectMocks
    private TaskController  taskController;

    @InjectMocks
    private ProductController productController;

    @InjectMocks
    private UserController userController;


    @Mock
    private TaskService  taskService ;

    @Mock
    private ProductService  productService ;

    @Mock
    private UserService userService;

    private MockMvc mockMvc;
      

    @Autowired
    private UserRepository userRepository;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(productController, taskController, userController).build();
    }
    
   @Test
 @Order(1)
     public void test_Controller_UserController_File() {
           String filePath = "src/main/java/com/examly/springapp/controller/UserController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }

     @Test
     @Order(2)
     public void test_Controller_TaskController_File() {
           String filePath = "src/main/java/com/examly/springapp/controller/TaskController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }

     @Test
     @Order(3)
     public void test_Controller_ProductController_File() {
           String filePath = "src/main/java/com/examly/springapp/controller/ProductController.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(4)
     public void test_Model_Task_File() {
           String filePath = "src/main/java/com/examly/springapp/model/Task.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(5)
     public void test_Model_Product_File() {
           String filePath = "src/main/java/com/examly/springapp/model/Product.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(6)
     public void test_Model_User_File() {
           String filePath = "src/main/java/com/examly/springapp/model/User.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }

     @Test
     @Order(7)
     public void test_Repository_ProductRepository_File() {
           String filePath = "src/main/java/com/examly/springapp/repository/ProductRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }

     @Test
     @Order(8)
     public void test_Repository_TaskRepository_File() {
           String filePath = "src/main/java/com/examly/springapp/repository/TaskRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(9)
     public void test_Repository_UserRepository_File() {
           String filePath = "src/main/java/com/examly/springapp/repository/UserRepository.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }

     @Test
     @Order(10)
     public void test_Service_UserService_File() {
           String filePath = "src/main/java/com/examly/springapp/service/UserService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(11)
     public void test_Service_TaskService_File() {
           String filePath = "src/main/java/com/examly/springapp/service/TaskService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }
     @Test
     @Order(12)
     public void test_Service_ProductService_File() {
           String filePath = "src/main/java/com/examly/springapp/service/ProductService.java";
           // Replace with the path to your file
           File file = new File(filePath);
           assertTrue(file.exists() && file.isFile());
     }


       // *****************************User Tests********************************************************
    // Test for creating a user
    @Test
    @Order(13)
    public void test_Create_User() throws Exception {
        User user = new User(1L, "John Doe", "john@example.com", "password123", "Customer");

        when(userService.addUser(any(User.class))).thenReturn(user);

        mockMvc.perform(post("/api/users")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john@example.com"))
                .andExpect(jsonPath("$.role").value("Customer"));
    }

    // Test for getting all users
    @Test
     @Order(14)
    public void test_Get_All_Users() throws Exception {
        User user1 = new User(1L, "John Doe", "john@example.com", "password123", "Customer");
        User user2 = new User(2L, "Jane Smith", "jane@example.com", "password456", "Seller");

        when(userService.getAllUsers()).thenReturn(Arrays.asList(user1, user2));

        mockMvc.perform(get("/api/users"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("John Doe"))
                .andExpect(jsonPath("$[1].name").value("Jane Smith"));
    }

    // Test for getting a user by ID
    @Test
    @Order(15)
    public void test_Get_User_By_Id() throws Exception {
        User user = new User(1L, "John Doe", "john@example.com", "password123", "Customer");

        when(userService.getUserById(1L)).thenReturn(user);

        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john@example.com"));
    }

    // Test for updating a user
    @Test
    @Order(16)
    public void test_Update_User() throws Exception {
        User existingUser = new User(1L, "John Doe", "john@example.com", "password123", "Customer");
        User updatedUser = new User(1L, "John Doe", "john.new@example.com", "newpassword123", "Seller");

        when(userService.updateUser(eq(1L), any(User.class))).thenReturn(updatedUser);

        mockMvc.perform(put("/api/users/1")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(updatedUser)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"))
                .andExpect(jsonPath("$.email").value("john.new@example.com"))
                .andExpect(jsonPath("$.role").value("Seller"));
    }

    // Test for deleting a user
    @Test
    @Order(17)
    public void test_Delete_User() throws Exception {
        doNothing().when(userService).deleteUser(1L);

        mockMvc.perform(delete("/api/users/1"))
                .andExpect(status().isNoContent());
    }

 
    //****************************** */Task Tests/****************************** */************************** */
     @Test
     @Order(19)
    public void test_Create_Task() throws Exception {
        User owner = new User(1L, "Owner User", "owner@example.com", "password123", "USER");
        Task task = new Task(1L, "Task 1", "Description for Task 1", 150.0, owner);

        when(taskService.addTask(any(Task.class))).thenReturn(task);

        mockMvc.perform(post("/api/tasks")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(task)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.taskName").value("Task 1"))
                .andExpect(jsonPath("$.description").value("Description for Task 1"))
                .andExpect(jsonPath("$.price").value(150.0))
                .andExpect(jsonPath("$.owner.id").value(1L));
    }

    // Test for getting all tasks
    @Test
    @Order(20)
    public void test_Get_All_Tasks() throws Exception {
        User owner = new User(1L, "Owner User", "owner@example.com", "password123", "USER");
        List<Task> taskList = Arrays.asList(
                new Task(1L, "Task 1", "Description for Task 1", 150.0, owner),
                new Task(2L, "Task 2", "Description for Task 2", 200.0, owner)
        );

        when(taskService.getAllTasks()).thenReturn(taskList);

        mockMvc.perform(get("/api/tasks"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].taskName").value("Task 1"))
                .andExpect(jsonPath("$[1].taskName").value("Task 2"));
    }

    // Test for getting a task by ID
    @Test
    @Order(21)
    public void test_Get_Task_By_Id() throws Exception {
        User owner = new User(1L, "Owner User", "owner@example.com", "password123", "USER");
        Task task = new Task(1L, "Task 1", "Description for Task 1", 150.0, owner);

        when(taskService.getTaskById(1L)).thenReturn(task);

        mockMvc.perform(get("/api/tasks/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.taskName").value("Task 1"))
                .andExpect(jsonPath("$.description").value("Description for Task 1"));
    }

    // Test for updating a task
    @Test
    @Order(22)
    public void test_Update_Task() throws Exception {
        User owner = new User(1L, "Owner User", "owner@example.com", "password123", "USER");
        Task existingTask = new Task(1L, "Task 1", "Description for Task 1", 150.0, owner);
        Task updatedTask = new Task(1L, "Updated Task", "Updated Description", 175.0, owner);

        when(taskService.updateTask(eq(1L), any(Task.class))).thenReturn(updatedTask);

        mockMvc.perform(put("/api/tasks/1")
                .contentType("application/json")
                .content(objectMapper.writeValueAsString(updatedTask)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.taskName").value("Updated Task"))
                .andExpect(jsonPath("$.description").value("Updated Description"))
                .andExpect(jsonPath("$.price").value(175.0));
    }

    // Test for deleting a task
    @Test
    @Order(23)
    public void test_Delete_Task() throws Exception {
        User owner = new User(1L, "Owner User", "owner@example.com", "password123", "USER");
        Task task = new Task(1L, "Task 1", "Description for Task 1", 150.0, owner);

        doNothing().when(taskService).deleteTask(1L);

        mockMvc.perform(delete("/api/tasks/1"))
                .andExpect(status().isNoContent());
    }

 
         //****************************** */product Tests/****************************** */***************** */

 // Test for creating a product
 @Test
 @Order(24)
 public void test_Create_Product() throws Exception {
     User seller = new User(1L, "Seller User", "seller@example.com", "password123", "SELLER");
     Product product = new Product(1L, "Product 1", "Description for Product 1", 100.0, 50, seller);

     when(productService.addProduct(any(Product.class))).thenReturn(product);

     mockMvc.perform(post("/api/products")
             .contentType("application/json")
             .content(objectMapper.writeValueAsString(product)))
             .andExpect(status().isCreated())
             .andExpect(jsonPath("$.productName").value("Product 1"))
             .andExpect(jsonPath("$.description").value("Description for Product 1"))
             .andExpect(jsonPath("$.price").value(100.0))
             .andExpect(jsonPath("$.stock").value(50))
             .andExpect(jsonPath("$.seller.id").value(1L));
 }

 // Test for getting all products
 @Test
 @Order(25)
 public void test_Get_All_Products() throws Exception {
     User seller = new User(1L, "Seller User", "seller@example.com", "password123", "SELLER");
     List<Product> productList = Arrays.asList(
             new Product(1L, "Product 1", "Description for Product 1", 100.0, 50, seller),
             new Product(2L, "Product 2", "Description for Product 2", 200.0, 30, seller)
     );

     when(productService.getAllProducts()).thenReturn(productList);

     mockMvc.perform(get("/api/products"))
             .andExpect(status().isOk())
             .andExpect(jsonPath("$[0].productName").value("Product 1"))
             .andExpect(jsonPath("$[1].productName").value("Product 2"));
 }

 // Test for getting a product by ID
 @Test
 @Order(26)
 public void test_Get_Product_By_Id() throws Exception {
     User seller = new User(1L, "Seller User", "seller@example.com", "password123", "SELLER");
     Product product = new Product(1L, "Product 1", "Description for Product 1", 100.0, 50, seller);

     when(productService.getProductById(1L)).thenReturn(product);

     mockMvc.perform(get("/api/products/1"))
             .andExpect(status().isOk())
             .andExpect(jsonPath("$.productName").value("Product 1"))
             .andExpect(jsonPath("$.description").value("Description for Product 1"));
 }

 // Test for updating a product
 @Test
 @Order(27)
 public void test_Update_Product() throws Exception {
     User seller = new User(1L, "Seller User", "seller@example.com", "password123", "SELLER");
     Product existingProduct = new Product(1L, "Product 1", "Description for Product 1", 100.0, 50, seller);
     Product updatedProduct = new Product(1L, "Updated Product", "Updated Description", 150.0, 60, seller);

     when(productService.updateProduct(eq(1L), any(Product.class))).thenReturn(updatedProduct);

     mockMvc.perform(put("/api/products/1")
             .contentType("application/json")
             .content(objectMapper.writeValueAsString(updatedProduct)))
             .andExpect(status().isOk())
             .andExpect(jsonPath("$.productName").value("Updated Product"))
             .andExpect(jsonPath("$.description").value("Updated Description"))
             .andExpect(jsonPath("$.price").value(150.0))
             .andExpect(jsonPath("$.stock").value(60));
 }

 // Test for deleting a product
 @Test
 @Order(28)
 public void test_Delete_Product() throws Exception {
     User seller = new User(1L, "Seller User", "seller@example.com", "password123", "SELLER");
     Product product = new Product(1L, "Product 1", "Description for Product 1", 100.0, 50, seller);

     doNothing().when(productService).deleteProduct(1L);

     mockMvc.perform(delete("/api/products/1"))
             .andExpect(status().isNoContent());
 }

//Here's the test case for verifying the @ManyToOne annotation in the Task entity file,

 @Test
 @Order(29)
    public void test_ManyToOne_Task_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/examly/springapp/model/Task.java";
        String searchString = "@ManyToOne";
        
        boolean containsString = false;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
        
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@ManyToOne'");
    }


    @Test
    @Order(30)
    public void test_ManyToOne_product_Annotation() throws IOException {
        // Path to the file to be tested
        String filePath = "src/main/java/com/examly/springapp/model/Product.java";
        String searchString = "@ManyToOne";
        
        boolean containsString = false;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(searchString)) {
                    containsString = true;
                    break;
                }
            }
        }
        
        // Assert that the string is present in the file
        assertTrue(containsString, "The file does not contain the string '@ManyToOne'");
    }
}
